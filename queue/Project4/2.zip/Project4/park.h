#ifndef PARK_H
    #define PARK_H
    #include "SqStack.h"
    #include <string>
    #include <ctime>
    #include "linkQueue.h"
    const int parkFirstSize = 100;
    const int parkFirstFee = 100;
	
#define fei(a, b) for(int i = a; i <= b; i++)
#define fej(a, b) for(int j = a; j <= b; j++)
#define fek(a, b) for(int k = a; k <= b; k++)
template <typename elemtype>
class parkStack:public SqStack<elemtype>
{
public:
    void setSize(int n);

    elemtype getElem(int n);
};

template <typename elemtype>
void parkStack<elemtype>::setSize(int n)
{
    this->stackSize = n;
}

template <typename elemtype>
elemtype parkStack<elemtype>::getElem(int n)
{
    return this->base + n;
}

class park
{
public:
    class carNode
    {
    public:
        string name;

        int time;

        carNode()
        {
            name = "";
            time = 0;
        }
    };

protected:
    int parkSize;

    int parkFee;

    int carInPark;

    parkStack<carNode> s;

    linkQueue<string> q;

public:
    void carIn(string name);

    void carOut(int n);

    int inCarNum();

    void display(ostream& out) ;

    void getByRand(int display);

    bool isEmpty();

    bool isFull();

    void setSize(int n);

    void setFee(int n);

    int outputFee();

    int caculateFee(int time);

    void clear();
	
	park();

	virtual ~park();
};
park::~park()
{
	clear();
}

park::park()
{
    int carInPark = 0;

    int parkSize = parkFirstSize;

    int parkFee = parkFirstFee;
}
void park::carIn(string name)
{
    q.enQueue(name);
}

void park::carOut(int n)
{
    parkStack<carNode> tmps;
    cout << " ͣ����ͣ����" << n << "��λ���ϳ���׼���뿪. " << endl;
    cout << " (1)";
    carNode tmp;
    if(n < carInPark)
    {
        cout << " ���г��ƺŵĳ������˳�ͣ������·: " << endl;
        for(int i = 0; i < carInPark - n - 1; i++)
        {
            s.pop(tmp);
            tmps.push(tmp);
            cout << "          " << tmp.name << endl;
        }
        cout << " (2)";
    }
    s.pop(tmp);
    int nowTime = clock();
    cout << " ����ͣ����" << n << "��λ���ϳ��ƺ�Ϊ" << tmp.name << "�����뿪��" << endl;
    cout << "     ͣ��ʱ��Ϊ: " << nowTime - tmp.time; 
    cout << "     Ӧ����ͣ����Ϊ: " << caculateFee(nowTime - tmp.time) << endl;;
    if(n < carInPark)
    {
        cout << " (3) ��ǰ�˳��ĳ����ٽ�ͣ����. " << endl;
        while(!tmps.isEmpty())
        {
            carNode temp;
            tmps.pop(temp);
            s.push(temp);
        }
        cout << " (4)";
    }
    int qn = q.getLength();
    if(qn > 0)
    {
        if(n == carInPark)
        {
            cout << " (2)";
        }
        string newCarName;
        q.deQueue(newCarName);
        cout << " ���⳵�ƺ�Ϊ" << newCarName << "�ĳ������ڽ�ͣ����. " << endl;
        carNode newCar;
        newCar.time = clock();
        newCar.name = newCarName;
        s.push(newCar);
    }
    else
        cout << " (2) ���ڳ��Ⲣ�޳���, ����޳�������" << endl;
}

int park::inCarNum()
{
    return carInPark;
}

void park::display(ostream& out)
{
    int sn = s.getLength();
    if(sn == 0)
    {
        cout << " ��ǰͣ������ͣ������" << endl;
    }
    else
    {
        cout << "                     ͣ������ͣ��������Ϣ" << endl;
        cout << "                 ���ƺ���            ����ʱ��" << endl;
        if(sn == 1)
        {
            carNode tmp;
            s.getTop(tmp);
            cout << "  base/top->[ 1] " << tmp.name << "            " << tmp.time << endl;
        }
        else
        {
            parkStack<park::carNode> tmps;
            park::carNode tmp;
            fei(1, sn)
            {
                s.pop(tmp);
                tmps.push(tmp);
                char xh[] = "[ i]";
                if(i < 10)
                    xh[2] = '0' + i;
                else
                {
                    xh[1] = '0' + i / 10;
                    xh[2] = '0' + i % 10;
                }
                if(i == 1)
                {
                    cout << "      base->" << xh << " " << tmp.name << "            " << tmp.time << endl;
                }
                else if(i == sn)
                {
                    cout << "       top->" << xh << " " << tmp.name << "            " << tmp.time << endl;
                }
                else
                {
                
                    cout << "            " << xh << " " << tmp.name << "            " << tmp.time << endl;
                }
            }
            while(!tmps.isEmpty())
            {
                tmps.pop(tmp);
                s.push(tmp);
            }
        }
    }

    int qn = q.getLength();
    if(qn == 0)
    {
        cout << " ��ǰͣ�������޺򳵳���" << endl;
    }
    else
    {
        cout << "                     ͣ������ͣ��������Ϣ" << endl;
        cout << "                            ���ƺ�" << endl;
        if(qn == 1)
        {
            string tmp;
            q.getFront(tmp);
            cout << "                front/rear->" << tmp << endl;
        }
        else
        {
            linkQueue<string> tmps;
            string tmp;
            fei(1, qn)
            {
                q.deQueue(tmp);
                tmps.enQueue(tmp);
                if(i == 1)
                    cout << "                     front->" << tmp << endl;
                else if(i == qn)
                    cout << "                      rear->" << tmp << endl;
                else
                    cout << "                            " << tmp << endl;
            }
        }
    }
}

ostream& operator <<(ostream& out, park& x)
{
    x.display(out);
    return out;
}

void park::getByRand(int display)
{
    clear();
    int n1 = rand() % 23 + 1;
    int n2 = rand() % 23 + 1;

    char sname[] = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    if(display)
    {
        cout << "                 ����ͣ������ͣ����Ϣ" << endl;
        cout << "             ���ƺ���            ����ʱ��" << endl;
    }
    //fei(1, n1)
	for(int i = 1; i <= n1; i++)
    {
        char xh[] = "[ i]";
        carNode tmp;
        tmp.name = 'A' + rand() % 26;
        tmp.time = clock();
       // fei(1, 9)
		for(int i = 1; i <= 9; i++)
            tmp.name += sname[rand() % (26 + 10)];
        s.push(tmp);
        carInPark++;
        if(i < 10)
            xh[2] = '0' + i;
        else
        {
            xh[1] = '0' + i / 10;
            xh[2] = '0' + i % 10;
        }
        if(display)
        {
            cout << "        " << xh << " " << tmp.name << "            " << tmp.time << endl;
        }
    }
    if(display)
        cout << "       ͣ���������Ϣ" << endl;
    fei(1, n2)
    {
        string tmp;
        tmp = 'A' + rand() % 26;
        fei(1, 9)
            tmp += sname[rand() % (26 + 10)];
        q.enQueue(tmp);
        if(display)
            cout << "             " << tmp << endl;
    }
}

bool park::isEmpty()
{
    if(carInPark == 0)
        return true;
    else
        return false;
}

bool park::isFull()
{
    if(carInPark == s.getStackSize())
        return true;
    else
        return false;
}

void park::setSize(int n)
{  
    parkSize = n;
    s.setSize(n);
}

void park::setFee(int n)
{
    parkFee = n;
}

int park::outputFee()
{
    return parkFee;
}

int park::caculateFee(int time)
{
    return parkFee * time;
}

void park::clear()
{
    carInPark = 0;
    s.clear();
    q.clear();
}
#endif